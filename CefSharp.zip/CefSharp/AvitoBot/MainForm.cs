﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;

namespace AvitoBot
{
	public partial class MainForm : Form
	{
		object _lockAction = new object();
		bool _isCompleted = false;
		bool checker = false;
		static Dictionary<string,string> repeat = new Dictionary<string,string>();


		public class Bet
		{
			public string Bookmaker { get; set; }
			public string Name { get; set; }
			public string EventLink { get; set; }
			public string EventName { get; set; }
			public string MetaData { get; set; }
			public string EventMetaData { get; set; }
			public string EventLeague { get; set; }
			public string Kreal { get; set; }
		}

		public MainForm()
		{
			InitializeComponent();

			webBrowser1.ProgressChanged += new WebBrowserProgressChangedEventHandler(webBrowser1_ProgressChanged);
			webBrowser1.ScriptErrorsSuppressed = true;

			// Установка уровня режима совместимости WebBrowser на 11
			SetWebBrowserCompatiblityLevel();


		}


		private void ClickMouse()
        {
			Point p = new Point();
			GetCursorPos(ref p);
			ClientToScreen(Handle, ref p);
			DoMouseLeftClick(p.x, p.y);
        }

		#region ИЗМЕНЕНИЕ РЕЖИМА СОВМЕСТИМОСТИ WebBrowser
		// MAGIC
		//http://www.cyberforum.ru/windows-forms/thread1637948.html#post8616074
		//https://blogs.msdn.microsoft.com/patricka/2015/01/12/controlling-webbrowser-control-compatibility/
		//Элемент управления WebBrowser по умолчанию работает в режиме совместимости с IE7. Чтобы переключить его на более новые версии необходимо создать ключ в реестре по пути
		//HKEY_LOCAL_MACHINE\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION
		// или HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION

		private static void SetWebBrowserCompatiblityLevel()
		{
			string appName = Path.GetFileNameWithoutExtension(Application.ExecutablePath);
			int lvl = 1000 * GetBrowserVersion();
			bool fixVShost = File.Exists(Path.ChangeExtension(Application.ExecutablePath, ".vshost.exe"));

			WriteCompatiblityLevel("HKEY_LOCAL_MACHINE", appName + ".exe", lvl);
			if (fixVShost) WriteCompatiblityLevel("HKEY_LOCAL_MACHINE", appName + ".vshost.exe", lvl);

			WriteCompatiblityLevel("HKEY_CURRENT_USER", appName + ".exe", lvl);
			if (fixVShost) WriteCompatiblityLevel("HKEY_CURRENT_USER", appName + ".vshost.exe", lvl);
		}

		private static void WriteCompatiblityLevel(string root, string appName, int lvl)
		{
			try
			{
				Microsoft.Win32.Registry.SetValue(root + @"\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION", appName, lvl);
			}
			catch (Exception)
			{
			}
		}

		public static int GetBrowserVersion()
		{
			string strKeyPath = @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer";
			string[] ls = new string[] { "svcVersion", "svcUpdateVersion", "Version", "W2kVersion" };

			int maxVer = 0;
			for (int i = 0; i < ls.Length; ++i)
			{
				object objVal = Microsoft.Win32.Registry.GetValue(strKeyPath, ls[i], "0");
				string strVal = Convert.ToString(objVal);
				if (strVal != null)
				{
					int iPos = strVal.IndexOf('.');
					if (iPos > 0)
						strVal = strVal.Substring(0, iPos);

					int res = 0;
					if (int.TryParse(strVal, out res))
						maxVer = Math.Max(maxVer, res);
				}
			}

			return maxVer;
		}
		#endregion

		#region PRIVATE METHODS

		// метод перехода на заданный url
		private void _navigate(string url)
		{
			lock (_lockAction)
			{
				webBrowser1.Navigate(url);

				_isCompleted = false;
				while (_isCompleted == false) Application.DoEvents();

			}
		}

		// получение html элемента поля 
		private HtmlElement _getLoginEl()
		{
			HtmlElement res = null;

			foreach (HtmlElement el in webBrowser1.Document.GetElementsByTagName("div"))
			{
				if (el.GetAttribute("className") == "sum-panel__input-wrap--W1NEU")
				{
					res = el;
					break;
				}
			}


			return res;
		}


		// получение html элмента кнопки входа
		private HtmlElement _getLoginButtonEl(string s)
		{
			HtmlElement res = null;


			foreach (HtmlElement el in webBrowser1.Document.GetElementsByTagName("div"))
			{
				if (el.GetAttribute("className") == s)
				{
					res = el;
					break;
				}
			}


			return res;
		}


		public int getXoffset(HtmlElement el)
		{
			//get element pos
			int xPos = el.OffsetRectangle.Left;

			//get the parents pos
			HtmlElement tempEl = el.OffsetParent;
			while (tempEl != null)
			{
				xPos += tempEl.OffsetRectangle.Left;
				tempEl = tempEl.OffsetParent;
			}

			return xPos;
		}

		public int getYoffset(HtmlElement el)
		{
			//get element pos
			int yPos = el.OffsetRectangle.Top;

			//get the parents pos
			HtmlElement tempEl = el.OffsetParent;
			while (tempEl != null)
			{
				yPos += tempEl.OffsetRectangle.Top;
				tempEl = tempEl.OffsetParent;
			}

			return yPos;
		}


		#endregion

		#region PUBLIC METHODS
		////////////////////////////
		// обработчик события завершения обновления страницы
		private void webBrowser1_ProgressChanged(object sender, WebBrowserProgressChangedEventArgs e)
		{
			if (webBrowser1.ReadyState == WebBrowserReadyState.Complete)
				_isCompleted = true;
		}
		public void pause1()
		{
			while (webBrowser1.ReadyState != WebBrowserReadyState.Complete)
			{
				Application.DoEvents();

			}
		}

		private void pause(int value)
		{
			Stopwatch sw = new Stopwatch();
			sw.Start();
			while (sw.ElapsedMilliseconds < value)
				Application.DoEvents();
		}

		private void wbPause(string s)
		{
			Int64 neew = new long();
			Int64 olld = new long();
		L2:
			try
			{
				pause(100); //даем секунду для начала загрузки страницы
				olld = 0;
			L1:
				pause(0);
				neew = 0;
				//начинаем считать все HtmlElement'ы 
				//тут если страница даже не начала грузиться, то возникнет System.NullReferenceException
				foreach (HtmlElement Pause in webBrowser1.Document.All)
				{
					neew += 1;
				}
				if (olld != neew)

				{
					olld = neew;
					goto L1;
				}
			}
			//перехватываем нулевую страничку
			catch (System.NullReferenceException)
			{
				pause(60000);
				webBrowser1.Navigate(s);
				goto L2;
			}
		}


		private async void buttonNavigateToAvito_Click(object sender, EventArgs e)
		{
			checker = true;

			HttpClient httpClient = new HttpClient();

			string request = "https://api.forksmarket.ru/api/testfonbet";
			HttpResponseMessage response =
				(await httpClient.GetAsync(request)).EnsureSuccessStatusCode();
			string responseBody = await response.Content.ReadAsStringAsync();

			JArray jarray = JArray.Parse(responseBody);

			for (int i = 0; i < jarray.Count; i++)
			{
				string toParse = "";
				try
				{
					toParse = jarray[i].ToString();
				}
				catch (ArgumentOutOfRangeException)
                {
					break;
                }
				Bet parser = JsonConvert.DeserializeObject<Bet>(toParse);
				try
				{
					repeat.Add(parser.EventName, parser.Name);
				}
				catch (ArgumentException)
                {
					continue;
                }

				if (parser.EventLink.Contains("/2") == true || parser.EventLink.Contains("l/3") == true)
				{

				}
				else
					continue;

				string s = textBox1.Text;
				_navigate(parser.EventLink);
				_isCompleted = false;
				lock (_lockAction)
				{

					while (_isCompleted == false) Application.DoEvents();
				}
				HtmlElement button = _getLoginButtonEl("t--39Sli");
				
				if (parser.Name.Contains("Over") == true || parser.Name.Contains("Under") == true || parser.Name.Contains("H") == true || parser.Name.Contains("OVER") == true || parser.Name.Contains("UNDER") == true || parser.Name.Contains("F") == true)
                {
					button = _getLoginButtonEl("v---x8Cq _v-only--2MX1l");
					foreach (HtmlElement el in webBrowser1.Document.GetElementsByTagName("div"))
					{
						if (el.InnerText == parser.Kreal && el.GetAttribute("className")== "v-- - x8Cq")
						{
							button = el;
							break;
						}
					}
					
					if (button == null) continue;
					else button.InvokeMember("Click");
				}

				if (parser.Name == "1" || parser.Name=="2" || parser.Name.Contains("X") == true || parser.Name.Contains("P") == true )
				{
					button = _getLoginButtonEl("v---x8Cq _v-only--2MX1l");
					foreach (HtmlElement el in webBrowser1.Document.GetElementsByTagName("div"))
					{
						if (el.InnerText == parser.Kreal && el.GetAttribute("className") == "v---x8Cq _v-only--2MX1l")
						{
							button = el;

							break;
						}
					}

					
					if (button == null) continue;
					else button.InvokeMember("Click");
				}

				

				// перемещение на поле сумме ставки
				MoveMouse(1485,258);
				ClickMouse();
				Thread.Sleep(100);
				SendKeys.Send(s);
				Thread.Sleep(50);
				MoveMouse(1515, 294);
				ClickMouse();




			}
		}

		private void buttonNavigateToLoginForm_Click(object sender, EventArgs e)
		{
			checker = false;
		}

		#endregion 

		private void MainForm_Load(object sender, EventArgs e)
		{
			_navigate("https://www.fonbet.ru/sports/");
			_isCompleted = false;

		}

		private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
		{

		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{

		}

		private void MoveMouse(int a, int b)
		{  
			Point p = new Point();
			p.x = Convert.ToInt16(a);
			p.y = Convert.ToInt16(b);
			ClientToScreen(Handle, ref p);
			SetCursorPos(p.x, p.y);
		}

		[DllImport("user32.dll")]
		public static extern long SetCursorPos(int x, int y);

		[DllImport("user32.dll")]
		public static extern bool ClientToScreen(IntPtr hWnd, ref Point point);

		[DllImport("user32.dll")]
		public static extern void mouse_event(int dsFlags, int dx, int dy, int cButtons, int dsExtraInfo);

		public const int MOUSEEVENTF_LEFTDOWN = 0x02;
		public const int MOUSEEVENTF_LEFTUP = 0x04;

		public const int MOUSEEVENTF_RIGHTDOWN = 0x08;
		public const int MOUSEEVENTF_RIGHTUP = 0x10;

		private void DoMouseLeftClick(int x, int y)
        {
			mouse_event(MOUSEEVENTF_LEFTDOWN, x, y, 0, 0);
			mouse_event(MOUSEEVENTF_LEFTUP, x, y, 0, 0);
		}
		private void DoMouseRightClick(int x, int y)
		{
			mouse_event(MOUSEEVENTF_RIGHTDOWN, x, y, 0, 0);
			mouse_event(MOUSEEVENTF_RIGHTUP, x, y, 0, 0);
		}

		[DllImport("user32.dll")]
		public static extern bool GetCursorPos(ref Point lpPoint);

		[StructLayout(LayoutKind.Sequential)]
		public struct Point
        {
			public int x;
			public int y;
        }
	}
}
